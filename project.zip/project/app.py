from flask import Flask, render_template, request, redirect, url_for, session
from flask_mysqldb import MySQL
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.secret_key = 'hack@me'

# MySQL Configuration
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = ''
app.config['MYSQL_DB'] = 'users_db'
app.config['MYSQL_CURSORCLASS'] = 'DictCursor'

mysql = MySQL(app)

# Initialize Database
def init_db():
    cur = mysql.connection.cursor()
    cur.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INT AUTO_INCREMENT PRIMARY KEY,
            username VARCHAR(100) NOT NULL,
            email VARCHAR(100) NOT NULL UNIQUE,
            password VARCHAR(255) NOT NULL,
            is_admin BOOLEAN DEFAULT FALSE
        )
    ''')

    cur.execute("SELECT * FROM users WHERE email = %s", ('admin@example.com',))
    if not cur.fetchone():
        hashed_password = generate_password_hash("admin123")
        cur.execute("INSERT INTO users (username, email, password, is_admin) VALUES (%s, %s, %s, %s)",
                    ('admin', 'admin@example.com', hashed_password, True))

    cur.execute('''
        CREATE TABLE IF NOT EXISTS posts (
            id INT AUTO_INCREMENT PRIMARY KEY,
            title VARCHAR(255) NOT NULL,
            content TEXT NOT NULL,
            author VARCHAR(100) NOT NULL,
            approved BOOLEAN DEFAULT FALSE
        )
    ''')

    mysql.connection.commit()
    cur.close()

@app.route('/')
def index():
    cur = mysql.connection.cursor()
    cur.execute("SELECT * FROM posts WHERE approved = TRUE")
    posts = cur.fetchall()
    cur.close()
    return render_template('index.html', posts=posts)

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']
        hashed_password = generate_password_hash(password)

        cur = mysql.connection.cursor()
        cur.execute("INSERT INTO users (username, email, password) VALUES (%s, %s, %s)", (username, email, hashed_password))
        mysql.connection.commit()
        cur.close()
        return redirect(url_for('login'))
    
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']

        cur = mysql.connection.cursor()
        cur.execute("SELECT * FROM users WHERE email = %s", [email])
        user = cur.fetchone()
        cur.close()

        if user and check_password_hash(user['password'], password):
            session['logged_in'] = True
            session['username'] = user['username']
            session['is_admin'] = user['is_admin']

            return redirect(url_for('admin' if user['is_admin'] else 'dashboard'))
    
    return render_template('login.html')

@app.route('/dashboard', methods=['GET', 'POST'])
def dashboard():
    if 'logged_in' in session:
        if request.method == 'POST':
            title = request.form['title']
            content = request.form['content']
            author = session['username']

            cur = mysql.connection.cursor()
            cur.execute("INSERT INTO posts (title, content, author) VALUES (%s, %s, %s)", (title, content, author))
            mysql.connection.commit()
            cur.close()

            return redirect(url_for('dashboard'))

        return render_template('dashboard.html', username=session['username'])
    return redirect(url_for('login'))

@app.route('/admin')
def admin():
    if 'logged_in' in session and session.get('is_admin'):
        cur = mysql.connection.cursor()
        cur.execute("SELECT id, username, email FROM users")
        users = cur.fetchall()

        cur.execute("SELECT * FROM posts WHERE approved = FALSE")
        pending_posts = cur.fetchall()

        cur.close()
        return render_template('admin.html', users=users, pending_posts=pending_posts)
    
    return redirect(url_for('login'))

@app.route('/approve_post/<int:post_id>')
def approve_post(post_id):
    if 'logged_in' in session and session.get('is_admin'):
        cur = mysql.connection.cursor()
        cur.execute("UPDATE posts SET approved = TRUE WHERE id = %s", (post_id,))
        mysql.connection.commit()
        cur.close()
        return redirect(url_for('admin'))
    
    return redirect(url_for('login'))

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))

if __name__ == '__main__':
    with app.app_context():
        init_db()
    app.run(debug=True)
